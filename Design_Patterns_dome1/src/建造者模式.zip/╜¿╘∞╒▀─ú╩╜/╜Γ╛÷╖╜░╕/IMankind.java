package 建造者模式.解决方案;

/**
 * 不同对象的接口
 */
public interface IMankind {
    void show();
}
